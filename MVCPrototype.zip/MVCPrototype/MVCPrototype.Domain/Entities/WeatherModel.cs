﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MVCPrototype.Domain.Entities
{
    public class WeatherModel
    {
        public string? Date { get; set; }

        public double Tmin2m { get; set; }
        public double Tmpsfc {  get; set; }
        public double Apcpsfc { get; set; }
        public double Lcdclcll { get; set; }
        public double Hcdchcll { get; set; }
        public double Mcdcmcll { get; set; }
        public double Sunsdsfc { get; set; }

        public string Summary => WeatherForecastSummary();

        private string WeatherForecastSummary()
        {
            double SunsdsfcHours = Sunsdsfc / 3600.0;

            double TotalCloudCover = Lcdclcll + Mcdcmcll + Hcdchcll;

            if (Tmin2m < 3 || Tmpsfc < 5)
                return "Freezing";

            if (Apcpsfc > 3.5 || TotalCloudCover > 80)
                return "Raining";

            if (SunsdsfcHours > 6 && TotalCloudCover < 40)
                return "Sunny";

            return "Smog";
        }

    }
}
