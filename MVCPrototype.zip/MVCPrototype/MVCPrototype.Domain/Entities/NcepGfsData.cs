﻿using System.Text.Json.Serialization;

namespace MVCPrototype.Domain.Entities
{
    public class NcepGfsData
    {
        [JsonPropertyName("horas")]
        public int Horas { get; set; }
        [JsonPropertyName("valor")]
        public double Valor { get; set; }
    }
}
