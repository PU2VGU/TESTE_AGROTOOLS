﻿namespace MVCPrototype.Domain.DTOs
{
    public class ShortWeatherForecastDto
    {
        public int TemperatureC { get; set; }
        public string? Summary { get; set; }
    }

}
