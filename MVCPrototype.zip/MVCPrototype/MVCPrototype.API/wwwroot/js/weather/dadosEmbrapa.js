import { weatherConditionPortuguese } from '../utils/translator.js';

const weather_container = $("#weather-table");
const ICON_SRC = "/icons";
const spinnerContainer = $("#spinner-container");

mountWeatherHeaders();

$.ajax({
    url: "/Weather/PrepareWeatherForecastModel",
    type: "GET",
    beforeSend: function () {
        spinnerContainer.show();
    },
    success: (response) => {
        for (const weather of response) {
            weather_container[0].appendChild(mountWeatherRow(weather));
        }
    },
    complete: function () {
        spinnerContainer.hide();
    }
});

function mountWeatherHeaders() {
    const headerRow = document.createElement("TR");
    const headers = [
        "Data",
        "Temperatura Mínima",
        "Temperatura na Superfície",
        "Precipitação",
        "Cobertura de Nuvens (Baixa)",
        "Cobertura de Nuvens (Média)",
        "Cobertura de Nuvens (Alta)",
        "Duração do Sol",
        "Clima"
    ];

    headers.forEach(header => {
        let th = document.createElement("TH");
        th.innerText = header;
        th.classList.add("weather-header");
        headerRow.appendChild(th);
    });

    weather_container[0].appendChild(headerRow);
}

function mountWeatherRow(weather_object) {
    let dataRow = document.createElement("TR");
    let values = [
         weather_object.date,
        `${weather_object.tmin2m} ºC`,
        `${weather_object.tmpsfc} ºC`,
        `${weather_object.apcpsfc} kg/m^2`,
        `${weather_object.lcdclcll}%`,
        `${weather_object.hcdchcll}%`,
        `${weather_object.mcdcmcll}%`,
        `${weather_object.sunsdsfc} s`,
        weatherConditionPortuguese(weather_object.summary)
    ];

    values.forEach(value => {
        let td = document.createElement("TD");
        td.innerText = value;
        td.classList.add("weather-col");
        dataRow.appendChild(td);
    });

    return dataRow;
}
