import { weatherConditionPortuguese } from '../utils/translator.js';
import { getDayFromDate } from '../utils/utils.js';
import { getNumberDayOfWeek } from '../utils/utils.js';
import { getIcon } from '../utils/utils.js';

const weather_container = $("#weather-calendar");
const today = new Date();
const mes = today.getMonth() + 1;
const ano = today.getFullYear();

$.ajax({
    url: `/Weather/GetWeatherCurrentMonthYear?month=${mes}&year=${ano}`,
    type: "GET",
    success: (response) => {
        let diaSemana = 0;
        let varredura = 0;
        while (varredura < response.length) {
            let weather = response[varredura];
            if (diaSemana == getNumberDayOfWeek(weather.date)) {
                weather_container[0].appendChild(mountWeatherDisplay(weather));
                ++varredura;
            } else {
                weather_container[0].appendChild(mountEmptyWeatherDisplay());
            }
            ++diaSemana;
            if (diaSemana > 6) diaSemana = 0;
        }
    }
});

function mountWeatherDisplay(weather_object) {
    let weather = document.createElement("DIV");
    weather.classList.add("weather-display");

    let header = document.createElement("SPAN");
    header.innerText = getDayFromDate(weather_object.date);
    let dayOfWeek = document.createElement("SPAN");
    dayOfWeek.innerText = "";

    let footer = document.createElement("SPAN");
    footer.innerText = weatherConditionPortuguese(weather_object.summary);

    let temperature = document.createElement("SPAN");
    temperature.classList.add("weather-temperature");
    //temperature.innerText = `${weather_object.temperatureC}`;
    temperature.innerText = weather_object.temperatureC;

    let icon = document.createElement("LABEL");
    icon.classList.add("weather-condition-icon-" + weather_object.summary.toLowerCase());

    getIcon(weather_object.summary).then(svgElement => {
        if (svgElement instanceof Node) {
            icon.appendChild(svgElement);
        } else {
            console.error("getIcon retornou um valor inv�lido:", svgElement);
        }
    });

    weather.appendChild(header);
    weather.appendChild(dayOfWeek);
    weather.appendChild(temperature);
    weather.appendChild(icon);
    weather.appendChild(footer);

    return weather;
}

function mountEmptyWeatherDisplay() {
    let weather = document.createElement("DIV");
    weather.classList.add("weather-empty-display");
    return weather;
}
