import { weatherConditionPortuguese } from '../utils/translator.js';

const weather_container = $("#weather-table");
const ICON_SRC = "/icons";
const spinnerContainer = $("#spinner-container");


$(document).ready(function () {
    $("#searchButton").click(function () {
        const startDate = $("#startDate").val();
        const endDate = $("#endDate").val();

        if (!startDate || !endDate) {
            alert("Por favor, selecione as datas.");
            return;
        }

        if (startDate > endDate) {
            alert("Por favor, a data inicial deve ser menor ou igual à data final.");
            return;
        }

        $("#weather-table").empty();

        mountWeatherHeaders();

        spinnerContainer.show();

        $.ajax({
            url: `/Weather/GetWeatherRangeDate?fromDate=${startDate}&toDate=${endDate}`,
            type: "GET",
            success: (response) => {
                spinnerContainer.hide();
                response.forEach(weather => {
                    $("#weather-table")[0].appendChild(mountWeatherRow(weather));
                });
            },
            error: () => {
                spinnerContainer.hide();
                $("#weather-table").html('<p class="text-danger">Erro ao carregar os dados.</p>');
            }
        });
    });
});


function mountWeatherHeaders() {
    const headerRow = document.createElement("TR");
    const headers = [
        "Temperatura",
        "Clima"
    ];

    headers.forEach(header => {
        let th = document.createElement("TH");
        th.innerText = header;
        th.classList.add("weather-header");
        headerRow.appendChild(th);
    });

    weather_container[0].appendChild(headerRow);
}

function mountWeatherRow(weather_object) {
    let dataRow = document.createElement("TR");
    let values = [
        `${weather_object.temperatureC} ºC`,
        weatherConditionPortuguese(weather_object.summary)
    ];

    values.forEach(value => {
        let td = document.createElement("TD");
        td.innerText = value;
        td.classList.add("weather-col");
        dataRow.appendChild(td);
    });

    return dataRow;
}
