﻿const ICON_SRC = "/icons";

export function getDayOfWeek(dateString) {
    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];
    //const date = parseDateUTC(dateString);
    //return daysOfWeek[date.getUTCDay()] ?? "Número inválido";

    return daysOfWeek[getNumberDayOfWeek(dateString)] ?? "Número inválido";
}

export function translateDayToPortuguese(dayInEnglish) {
    const daysDictionary = {
        "Sunday": "Domingo",
        "Monday": "Segunda-feira",
        "Tuesday": "Terça-feira",
        "Wednesday": "Quarta-feira",
        "Thursday": "Quinta-feira",
        "Friday": "Sexta-feira",
        "Saturday": "Sábado"
    };

    return daysDictionary[dayInEnglish] || "Dia inválido";
}

export function getDayFromDate(dateString) {
   const [year, month, day] = dateString.split("-").map(Number);
   return day;
}

export function getNumberDayOfWeek(dateString) {
    const date = parseDateUTC(dateString);
    return date.getUTCDay();
}

function parseDateUTC(dateString) {
    const [year, month, day] = dateString.split("-").map(Number);
    return new Date(Date.UTC(year, month - 1, day));
}

export async function getIcon(summary) {
    let iconPath = "";

    switch (summary) {
        case "Freezing":
            iconPath = ICON_SRC + "/snowflake-solid.svg";
            break;
        case "Smog":
            iconPath = ICON_SRC + "/smog-solid.svg";
            break;
        case "Sunny":
            iconPath = ICON_SRC + "/sun-solid.svg";
            break;
        case "Raining":
            iconPath = ICON_SRC + "/rain-solid.svg";
            break;
    }

    const response = await fetch(iconPath);
    const svgText = await response.text();

    const tempDiv = document.createElement("DIV");
    tempDiv.innerHTML = svgText.trim();

    let svgElement = tempDiv.querySelector("svg");
    if (svgElement) {
        svgElement.classList.add("weather-icon");
        return svgElement;
    }
}


export async function getIconStyle(summary) {
    let iconPath = "";

    switch (summary) {
        case "Freezing":
            iconPath = ICON_SRC + "/snowflake-solid.svg";
            break;
        case "Smog":
            iconPath = ICON_SRC + "/smog-solid.svg";
            break;
        case "Sunny":
            iconPath = ICON_SRC + "/sun-solid.svg";
            break;
        case "Raining":
            iconPath = ICON_SRC + "/rain-solid.svg";
            break;
    }

    const response = await fetch(iconPath);
    const svgText = await response.text();

    const tempDiv = document.createElement("DIV");
    tempDiv.innerHTML = svgText.trim();

    let svgElement = tempDiv.querySelector("svg");
    if (svgElement) {
        svgElement.classList.add("weather-icon");
        return svgElement;
    }
}