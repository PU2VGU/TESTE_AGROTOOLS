export function weatherConditionPortuguese(summary) {
    let weatherCondition = summary
    switch (summary) {
        case "Freezing":
            weatherCondition = "Congelante";
            break;
        case "Smog":
            weatherCondition = "Nublado";
            break;
        case "Sunny":
            weatherCondition = "Ensolarado";
            break;
        case "Raining":
            weatherCondition = "Chuvoso";
            break;
    }
    return weatherCondition;
}



