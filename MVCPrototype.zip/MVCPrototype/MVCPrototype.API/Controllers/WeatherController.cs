using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MVCPrototype.Application.Services;
using MVCPrototype.Domain.DTOs;

namespace MVCPrototype.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherController : ControllerBase
    {
        protected readonly IConfiguration _configuration;
        private readonly IWeatherService _weatherService;
        private readonly IClimApiEmbrapaService _climApiEmbrapa;
        private readonly IWeatherForecastService _weatherForecastService;

        public WeatherController(IConfiguration configuration, IWeatherService weatherService, IClimApiEmbrapaService climApiEmbrapa, IWeatherForecastService weatherForecastService)
        {
            _configuration = configuration;
            _weatherService = weatherService;
            _climApiEmbrapa = climApiEmbrapa;
            _weatherForecastService = weatherForecastService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var response = _weatherService.GetWeather(DateTime.Now);
                return StatusCode(200, response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = "Requisi��o inv�lida.", details = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Erro interno no servidor.", details = ex.Message });
            }
        }


        [Route("GetWeatherRangeDate")]
        [HttpGet]
        public IActionResult getWeatherRangeDate(DateTime fromDate, DateTime toDate)
        {
            try
            {
                var response = _weatherService.GetWeatherRangeDate(fromDate, toDate)
                    .Select(weather => new ShortWeatherForecastDto
                    {
                        TemperatureC = weather.TemperatureC,
                        Summary = weather.Summary
                    });

                return StatusCode(200, response);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                return BadRequest(new { message = ex.ParamName, details = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = "Requisi��o inv�lida.", details = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Erro interno no servidor.", details = ex.Message });
            }
        }

        [Route("GetWeatherCurrentMonthYear")]
        [HttpGet]
        public IActionResult getWeatherCurrentMonthYear(short month, short year)
        {
            try
            {
                var response = _weatherService.GetWeatherCurrentMonthYear(month, year);
                return StatusCode(200, response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = "Argumento inv�lido", details = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Erro interno no servidor.", details = ex.Message });
            }
        }

        [Route("PrepareWeatherForecastModel")]
        [HttpGet]
        public async Task<IActionResult> PrepareWeatherForecastModel()
        {
            try
            {
                var weatherModel = await _weatherForecastService.PrepareWeatherModel("-45.9009", "-23.2237");
                return StatusCode(200, weatherModel);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = "Requisi��o inv�lida.", details = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Erro interno no servidor.", details = ex.Message });
            }
        }

    }
}
