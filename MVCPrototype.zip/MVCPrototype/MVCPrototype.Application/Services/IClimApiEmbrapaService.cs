﻿using MVCPrototype.Domain.Entities;

namespace MVCPrototype.Application.Services
{
    public interface IClimApiEmbrapaService
    {
        Task<List<string>> GetAvailableDatesNcepGfs(string variable);
        Task<List<NcepGfsData>> GetDataByVariable(string variable, string date, string longitude, string latitude);
    }
}