﻿using MVCPrototype.Domain.Entities;
using System.Globalization;
using System.IO.Pipes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MVCPrototype.Application.Services
{
    public class WeatherService : IWeatherService
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Raining", "Smog", "Sunny"
        };

        public WeatherService() { }

        public IEnumerable<WeatherForecast> GetWeather(DateTime datePrediction)
        {
            return Enumerable.Range(0, 7).Select(index => GetWeatherOnDate(datePrediction.AddDays(index))).ToArray();
        }

        public IEnumerable<WeatherForecast> GetWeatherRangeDate(DateTime fromDate, DateTime toDate)
        {
            if (fromDate > toDate)
                throw new ArgumentOutOfRangeException("A data final deve ser maior ou igual à data inicial.");

            if ((toDate - fromDate).TotalDays > 30)
                throw new ArgumentOutOfRangeException("A previsão do tempo está restrita a um intervalo de até 30 dias.");

            return Enumerable.Range(0, GetDaysDifference(fromDate, toDate)+1).Select(index => GetWeatherOnDate(fromDate.AddDays(index))).ToArray();
        }

        public IEnumerable<WeatherForecast> GetWeatherCurrentMonthYear(short month, short year)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month), "O número do mês deve estar entre 1 e 12.");

            if (year < (DateTime.Now).Year)
                throw new ArgumentOutOfRangeException(nameof(month), "O ano deve ser maior ou igual ao ano corrente.");

            var monthYear = string.Concat(month.ToString("D2"), "-", year.ToString("D4"));
            var fromDate = ConvertToDate(string.Concat("01-", monthYear));
            var toDate = ConvertToDate(string.Concat(DateTime.DaysInMonth(year, month).ToString("D2"),"-", monthYear));
            return GetWeatherRangeDate(fromDate, toDate);
        }

        private WeatherForecast GetWeatherOnDate(DateTime date)
        {
            return (new WeatherForecast
            {
                Date = DateOnly.FromDateTime(date),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            });
        }

        private int GetDaysDifference(DateTime startDate, DateTime endDate)
        {
            return (endDate.Date - startDate.Date).Days;
        }

        private DateTime ConvertToDate(string dateString)
        {
            if (DateTime.TryParseExact(dateString, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
            {
                return date.Date; // Garante que a hora seja 00:00:00
            }
            throw new ArgumentException("Formato de data inválido. Use dd-MM-yyyy.");
        }
    }
}

