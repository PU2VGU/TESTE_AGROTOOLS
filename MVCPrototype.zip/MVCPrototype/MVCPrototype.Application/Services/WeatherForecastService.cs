﻿using System.Globalization;
using MVCPrototype.Domain.Entities;
using System.Text.Json;

namespace MVCPrototype.Application.Services
{
    public class WeatherForecastService : IWeatherForecastService
    {

        private readonly IClimApiEmbrapaService _climApiEmbrapa;
        private const string Tmin2m = "tmin2m";
        private const string Tmpsfc = "tmpsfc";
        private const string Apcpsfc = "apcpsfc";
        private const string Lcdclcll = "lcdclcll";
        private const string Hcdchcll = "hcdchcll";
        private const string Mcdcmcll = "mcdcmcll";
        private const string Sunsdsfc = "sunsdsfc";

        public WeatherForecastService(IClimApiEmbrapaService climApiEmbrapa)
        {
            _climApiEmbrapa = climApiEmbrapa;
        }

        public async Task<List<WeatherModel>> PrepareWeatherModel(string longitude, string latitude)
        {
            var weatherModel = new List<WeatherModel>();

            var availableDates = await _climApiEmbrapa.GetAvailableDatesNcepGfs(Tmin2m);

            foreach (var dateItem in availableDates.OrderBy(x => x)) {
                await ProcessarLista(weatherModel, Tmin2m, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Tmpsfc, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Apcpsfc, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Lcdclcll, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Hcdchcll, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Mcdcmcll, dateItem, longitude, latitude);
                await ProcessarLista(weatherModel, Sunsdsfc, dateItem, longitude, latitude);
            }

            var valor = JsonSerializer.Serialize(weatherModel);

            return weatherModel;
        }

        private async Task ProcessarLista(List<WeatherModel> weatherModel, string variable, string date, string longitude, string latitude)
        {
            var validHours = new HashSet<int> { 6, 24, 48, 72, 96, 120, 144, 168, 192, 216, 240 };

            var dataForVariable = await _climApiEmbrapa.GetDataByVariable(variable, date, longitude, latitude);

            var specificHours = dataForVariable.Where(d => validHours.Contains(d.Horas)).ToList();

            foreach (var value in specificHours)
            {
                var dateReference = value.Horas == 6 ? date : ConvertDate(date).AddHours(value.Horas).ToString("yyyy-MM-dd");

                var dadosDoDia = weatherModel.Find(x => x.Date == dateReference);
                if (dadosDoDia is null)
                {
                    dadosDoDia = new WeatherModel() { Date = dateReference };
                    weatherModel.Add(dadosDoDia);
                }

                switch (variable)
                {
                   case Tmin2m:
                        dadosDoDia.Tmin2m = value.Valor;
                        break;
                    case Tmpsfc:
                        dadosDoDia.Tmpsfc = value.Valor;
                        break;
                    case Apcpsfc:
                        dadosDoDia.Apcpsfc = value.Valor;
                        break;
                    case Lcdclcll:
                        dadosDoDia.Lcdclcll = value.Valor;
                        break;
                    case Hcdchcll:
                        dadosDoDia.Hcdchcll = value.Valor;
                        break;
                    case Mcdcmcll:
                        dadosDoDia.Mcdcmcll = value.Valor;
                        break;
                    case Sunsdsfc:
                        dadosDoDia.Sunsdsfc = value.Valor;
                        break;
                }
            }
        }

        private DateTime ConvertDate(string date)
        {
            return DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        }
    }
}
