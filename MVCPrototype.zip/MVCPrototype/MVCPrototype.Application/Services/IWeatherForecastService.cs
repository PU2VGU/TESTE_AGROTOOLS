﻿using MVCPrototype.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCPrototype.Application.Services
{
    public interface IWeatherForecastService
    {
        Task<List<WeatherModel>> PrepareWeatherModel(string longitude, string latitude);
    }
}
