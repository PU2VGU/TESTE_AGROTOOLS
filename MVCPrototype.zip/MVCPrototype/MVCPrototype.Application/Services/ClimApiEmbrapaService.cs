﻿using MVCPrototype.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MVCPrototype.Application.Services
{
    public class ClimApiEmbrapaService : IClimApiEmbrapaService
    {
        private const string BASE_URL = "https://api.cnptia.embrapa.br/climapi/v1";
        private const string CONSUMER_KEY = "nzjEyzq4fp3aOZs26ZWwZawzoAga";
        private const string SECRET_KEY = "VMQh82_Kl1m386fRW0o1tcU9wJwa";
        private const string ACCESS_TOKEN = "832764f6-2c94-3c14-a75c-8a8f3be87c17";
        private const string NCEP_GFS = "/ncep-gfs/";

        public async Task<List<string>> GetAvailableDatesNcepGfs(string variable)
        {
            HttpClient client = new HttpClient();

            try
            {
                if (string.IsNullOrWhiteSpace(variable))
                    throw new ArgumentException("A variável meteorológica é obrigatória.");

                string url = $"{BASE_URL}{NCEP_GFS}{variable}";
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ACCESS_TOKEN);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                    throw new Exception($"Erro ao obter dados: {response.StatusCode}");

                string responseBody = await response.Content.ReadAsStringAsync();

                var result = JsonSerializer.Deserialize<List<string>>(responseBody);

                return result ?? new List<string>();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception("Erro de conexão com a API externa.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro inesperado ao buscar as datas disponíveis.", ex);
            }
        }

        public async Task<List<NcepGfsData>> GetDataByVariable(string variable, string date, string longitude, string latitude)
        {
            HttpClient client = new HttpClient();

            try
            {
                if (string.IsNullOrWhiteSpace(variable))
                    throw new ArgumentException("A variável meteorológica é obrigatória.");

                string url = $"{BASE_URL}{NCEP_GFS}{variable}/{date}/{longitude}/{latitude}";
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ACCESS_TOKEN);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                    throw new Exception($"Erro ao obter dados: {response.StatusCode}");

                string responseBody = await response.Content.ReadAsStringAsync();

                var result = JsonSerializer.Deserialize<List<NcepGfsData>>(responseBody);

                return result ?? new List<NcepGfsData>();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception("Erro de conexão com a API externa.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro inesperado ao buscar as datas disponíveis.", ex);
            }
        }

    }
}
