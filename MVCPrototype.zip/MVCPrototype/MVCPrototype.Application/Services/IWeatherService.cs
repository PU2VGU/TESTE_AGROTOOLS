﻿using MVCPrototype.Domain.Entities;

namespace MVCPrototype.Application.Services
{
    public interface IWeatherService
    {
        //IEnumerable<WeatherForecast> GetWeather();
        IEnumerable<WeatherForecast> GetWeather(DateTime datePrediction);

        IEnumerable<WeatherForecast> GetWeatherRangeDate(DateTime fromDate, DateTime toDate);

        IEnumerable<WeatherForecast> GetWeatherCurrentMonthYear(short month, short year);

    }
}
